﻿namespace СВГК
{
    partial class Performance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Performance));
            this.аринаDataSet = new СВГК.аринаDataSet();
            this.монтажные_раюотыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.монтажные_раюотыTableAdapter = new СВГК.аринаDataSetTableAdapters.Монтажные_раюотыTableAdapter();
            this.tableAdapterManager = new СВГК.аринаDataSetTableAdapters.TableAdapterManager();
            this.монтажные_раюотыBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.монтажные_раюотыBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.knijni_magazDataSet = new СВГК.knijni_magazDataSet();
            this.avtorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.avtorTableAdapter = new СВГК.knijni_magazDataSetTableAdapters.avtorTableAdapter();
            this.tableAdapterManager1 = new СВГК.knijni_magazDataSetTableAdapters.TableAdapterManager();
            this.avtorDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.janriBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.janriTableAdapter = new СВГК.knijni_magazDataSetTableAdapters.janriTableAdapter();
            this.janriDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.аринаDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.монтажные_раюотыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.монтажные_раюотыBindingNavigator)).BeginInit();
            this.монтажные_раюотыBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.knijni_magazDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avtorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avtorDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // аринаDataSet
            // 
            this.аринаDataSet.DataSetName = "аринаDataSet";
            this.аринаDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // монтажные_раюотыBindingSource
            // 
            this.монтажные_раюотыBindingSource.DataMember = "Монтажные раюоты";
            this.монтажные_раюотыBindingSource.DataSource = this.аринаDataSet;
            // 
            // монтажные_раюотыTableAdapter
            // 
            this.монтажные_раюотыTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = СВГК.аринаDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ЗаказчикиTableAdapter = null;
            this.tableAdapterManager.Монтажные_раюотыTableAdapter = this.монтажные_раюотыTableAdapter;
            this.tableAdapterManager.ПроектированиеTableAdapter = null;
            // 
            // монтажные_раюотыBindingNavigator
            // 
            this.монтажные_раюотыBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.монтажные_раюотыBindingNavigator.BindingSource = this.монтажные_раюотыBindingSource;
            this.монтажные_раюотыBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.монтажные_раюотыBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.монтажные_раюотыBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.монтажные_раюотыBindingNavigatorSaveItem});
            this.монтажные_раюотыBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.монтажные_раюотыBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.монтажные_раюотыBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.монтажные_раюотыBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.монтажные_раюотыBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.монтажные_раюотыBindingNavigator.Name = "монтажные_раюотыBindingNavigator";
            this.монтажные_раюотыBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.монтажные_раюотыBindingNavigator.Size = new System.Drawing.Size(494, 25);
            this.монтажные_раюотыBindingNavigator.TabIndex = 0;
            this.монтажные_раюотыBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // монтажные_раюотыBindingNavigatorSaveItem
            // 
            this.монтажные_раюотыBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.монтажные_раюотыBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("монтажные_раюотыBindingNavigatorSaveItem.Image")));
            this.монтажные_раюотыBindingNavigatorSaveItem.Name = "монтажные_раюотыBindingNavigatorSaveItem";
            this.монтажные_раюотыBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.монтажные_раюотыBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.монтажные_раюотыBindingNavigatorSaveItem.Click += new System.EventHandler(this.монтажные_раюотыBindingNavigatorSaveItem_Click);
            // 
            // knijni_magazDataSet
            // 
            this.knijni_magazDataSet.DataSetName = "knijni_magazDataSet";
            this.knijni_magazDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // avtorBindingSource
            // 
            this.avtorBindingSource.DataMember = "avtor";
            this.avtorBindingSource.DataSource = this.knijni_magazDataSet;
            // 
            // avtorTableAdapter
            // 
            this.avtorTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.avtorTableAdapter = this.avtorTableAdapter;
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.clientiTableAdapter = null;
            this.tableAdapterManager1.izdatelstvoTableAdapter = null;
            this.tableAdapterManager1.janriTableAdapter = this.janriTableAdapter;
            this.tableAdapterManager1.kniga_izdatelstvoTableAdapter = null;
            this.tableAdapterManager1.knigiTableAdapter = null;
            this.tableAdapterManager1.postavkaTableAdapter = null;
            this.tableAdapterManager1.sotrudnikiTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = СВГК.knijni_magazDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager1.zakaziTableAdapter = null;
            // 
            // avtorDataGridView
            // 
            this.avtorDataGridView.AutoGenerateColumns = false;
            this.avtorDataGridView.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.avtorDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.avtorDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.avtorDataGridView.DataSource = this.avtorBindingSource;
            this.avtorDataGridView.Location = new System.Drawing.Point(0, 53);
            this.avtorDataGridView.Name = "avtorDataGridView";
            this.avtorDataGridView.Size = new System.Drawing.Size(243, 308);
            this.avtorDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn1.HeaderText = "id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "FIO";
            this.dataGridViewTextBoxColumn2.HeaderText = "FIO";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // janriBindingSource
            // 
            this.janriBindingSource.DataMember = "janri";
            this.janriBindingSource.DataSource = this.knijni_magazDataSet;
            // 
            // janriTableAdapter
            // 
            this.janriTableAdapter.ClearBeforeFill = true;
            // 
            // janriDataGridView
            // 
            this.janriDataGridView.AutoGenerateColumns = false;
            this.janriDataGridView.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.janriDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.janriDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.janriDataGridView.DataSource = this.janriBindingSource;
            this.janriDataGridView.Location = new System.Drawing.Point(249, 53);
            this.janriDataGridView.Name = "janriDataGridView";
            this.janriDataGridView.Size = new System.Drawing.Size(243, 308);
            this.janriDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn3.HeaderText = "id";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "naimenovanie";
            this.dataGridViewTextBoxColumn4.HeaderText = "naimenovanie";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(105, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Авторы";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(331, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Жанры";
            // 
            // Performance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(494, 363);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.janriDataGridView);
            this.Controls.Add(this.avtorDataGridView);
            this.Controls.Add(this.монтажные_раюотыBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Performance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторы и жанры";
            this.Load += new System.EventHandler(this.Performance_Load);
            ((System.ComponentModel.ISupportInitialize)(this.аринаDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.монтажные_раюотыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.монтажные_раюотыBindingNavigator)).EndInit();
            this.монтажные_раюотыBindingNavigator.ResumeLayout(false);
            this.монтажные_раюотыBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.knijni_magazDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avtorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avtorDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.janriDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private аринаDataSet аринаDataSet;
        private System.Windows.Forms.BindingSource монтажные_раюотыBindingSource;
        private аринаDataSetTableAdapters.Монтажные_раюотыTableAdapter монтажные_раюотыTableAdapter;
        private аринаDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator монтажные_раюотыBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton монтажные_раюотыBindingNavigatorSaveItem;
        private knijni_magazDataSet knijni_magazDataSet;
        private System.Windows.Forms.BindingSource avtorBindingSource;
        private knijni_magazDataSetTableAdapters.avtorTableAdapter avtorTableAdapter;
        private knijni_magazDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private knijni_magazDataSetTableAdapters.janriTableAdapter janriTableAdapter;
        private System.Windows.Forms.DataGridView avtorDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource janriBindingSource;
        private System.Windows.Forms.DataGridView janriDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}