﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace СВГК
{
    public partial class Client : Form
    {
        public Client()
        {
            InitializeComponent();
        }

        private void заказчикBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
           

        }

        private void Client_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "knijni_magazDataSet.clienti". При необходимости она может быть перемещена или удалена.
            this.clientiTableAdapter.Fill(this.knijni_magazDataSet.clienti);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "аринаDataSet.Заказчики". При необходимости она может быть перемещена или удалена.
            this.заказчикиTableAdapter.Fill(this.аринаDataSet.Заказчики);


        }



        private void bindingNavigatorCountItem_Click(object sender, EventArgs e)
        {
            
        }

        private void заказчикиBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.заказчикиBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.аринаDataSet);

        }
    }
}
