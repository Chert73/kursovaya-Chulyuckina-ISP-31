﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace СВГК
{
    public partial class Performance : Form
    {
        public Performance()
        {
            InitializeComponent();
        }

        private void выполнениеBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
           

        }

        private void Performance_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "knijni_magazDataSet.janri". При необходимости она может быть перемещена или удалена.
            this.janriTableAdapter.Fill(this.knijni_magazDataSet.janri);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "knijni_magazDataSet.avtor". При необходимости она может быть перемещена или удалена.
            this.avtorTableAdapter.Fill(this.knijni_magazDataSet.avtor);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "аринаDataSet.Монтажные_раюоты". При необходимости она может быть перемещена или удалена.
            this.монтажные_раюотыTableAdapter.Fill(this.аринаDataSet.Монтажные_раюоты);

        }

        private void монтажные_раюотыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.монтажные_раюотыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.аринаDataSet);

        }
    }
}
