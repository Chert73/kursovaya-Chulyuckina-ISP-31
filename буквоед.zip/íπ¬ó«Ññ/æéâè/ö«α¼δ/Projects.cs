﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace СВГК
{
    public partial class Projects : Form
    {
        public Projects()
        {
            InitializeComponent();
        }

        private void проектBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
           
        }

        private void Projects_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "knijni_magazDataSet.knigi". При необходимости она может быть перемещена или удалена.
            this.knigiTableAdapter.Fill(this.knijni_magazDataSet.knigi);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "аринаDataSet.Проектирование". При необходимости она может быть перемещена или удалена.
            this.проектированиеTableAdapter.Fill(this.аринаDataSet.Проектирование);


        }

        private void проектированиеBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.проектированиеBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.аринаDataSet);

        }
    }
}
