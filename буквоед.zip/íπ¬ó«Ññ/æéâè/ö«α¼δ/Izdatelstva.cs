﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace СВГК.Формы
{
    public partial class Izd : Form
    {
        public Izd()
        {
            InitializeComponent();
        }

        private void Izd_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "knijni_magazDataSet._kniga_izdatelstvo". При необходимости она может быть перемещена или удалена.
            this.kniga_izdatelstvoTableAdapter.Fill(this.knijni_magazDataSet._kniga_izdatelstvo);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "knijni_magazDataSet.izdatelstvo". При необходимости она может быть перемещена или удалена.
            this.izdatelstvoTableAdapter.Fill(this.knijni_magazDataSet.izdatelstvo);

        }

        private void izdatelstvoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.izdatelstvoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.knijni_magazDataSet);

        }
    }
}
