﻿namespace СВГК
{
    partial class Izdatelstva
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Izdatelstva));
            this.knijni_magazDataSet = new СВГК.knijni_magazDataSet();
            this.izdatelstvoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.izdatelstvoTableAdapter = new СВГК.knijni_magazDataSetTableAdapters.izdatelstvoTableAdapter();
            this.tableAdapterManager = new СВГК.knijni_magazDataSetTableAdapters.TableAdapterManager();
            this.kniga_izdatelstvoTableAdapter = new СВГК.knijni_magazDataSetTableAdapters.kniga_izdatelstvoTableAdapter();
            this.izdatelstvoBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.izdatelstvoBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.izdatelstvoDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kniga_izdatelstvoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kniga_izdatelstvoDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.knijni_magazDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.izdatelstvoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.izdatelstvoBindingNavigator)).BeginInit();
            this.izdatelstvoBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.izdatelstvoDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kniga_izdatelstvoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kniga_izdatelstvoDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // knijni_magazDataSet
            // 
            this.knijni_magazDataSet.DataSetName = "knijni_magazDataSet";
            this.knijni_magazDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // izdatelstvoBindingSource
            // 
            this.izdatelstvoBindingSource.DataMember = "izdatelstvo";
            this.izdatelstvoBindingSource.DataSource = this.knijni_magazDataSet;
            // 
            // izdatelstvoTableAdapter
            // 
            this.izdatelstvoTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.avtorTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.clientiTableAdapter = null;
            this.tableAdapterManager.izdatelstvoTableAdapter = this.izdatelstvoTableAdapter;
            this.tableAdapterManager.janriTableAdapter = null;
            this.tableAdapterManager.kniga_izdatelstvoTableAdapter = this.kniga_izdatelstvoTableAdapter;
            this.tableAdapterManager.knigiTableAdapter = null;
            this.tableAdapterManager.postavkaTableAdapter = null;
            this.tableAdapterManager.sotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = СВГК.knijni_magazDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.zakaziTableAdapter = null;
            // 
            // kniga_izdatelstvoTableAdapter
            // 
            this.kniga_izdatelstvoTableAdapter.ClearBeforeFill = true;
            // 
            // izdatelstvoBindingNavigator
            // 
            this.izdatelstvoBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.izdatelstvoBindingNavigator.BindingSource = this.izdatelstvoBindingSource;
            this.izdatelstvoBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.izdatelstvoBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.izdatelstvoBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.izdatelstvoBindingNavigatorSaveItem});
            this.izdatelstvoBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.izdatelstvoBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.izdatelstvoBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.izdatelstvoBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.izdatelstvoBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.izdatelstvoBindingNavigator.Name = "izdatelstvoBindingNavigator";
            this.izdatelstvoBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.izdatelstvoBindingNavigator.Size = new System.Drawing.Size(697, 25);
            this.izdatelstvoBindingNavigator.TabIndex = 0;
            this.izdatelstvoBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // izdatelstvoBindingNavigatorSaveItem
            // 
            this.izdatelstvoBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.izdatelstvoBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("izdatelstvoBindingNavigatorSaveItem.Image")));
            this.izdatelstvoBindingNavigatorSaveItem.Name = "izdatelstvoBindingNavigatorSaveItem";
            this.izdatelstvoBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.izdatelstvoBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.izdatelstvoBindingNavigatorSaveItem.Click += new System.EventHandler(this.izdatelstvoBindingNavigatorSaveItem_Click);
            // 
            // izdatelstvoDataGridView
            // 
            this.izdatelstvoDataGridView.AutoGenerateColumns = false;
            this.izdatelstvoDataGridView.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.izdatelstvoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.izdatelstvoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.izdatelstvoDataGridView.DataSource = this.izdatelstvoBindingSource;
            this.izdatelstvoDataGridView.Location = new System.Drawing.Point(0, 28);
            this.izdatelstvoDataGridView.Name = "izdatelstvoDataGridView";
            this.izdatelstvoDataGridView.Size = new System.Drawing.Size(444, 394);
            this.izdatelstvoDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn1.HeaderText = "id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "adres";
            this.dataGridViewTextBoxColumn2.HeaderText = "adres";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "naimenovanie";
            this.dataGridViewTextBoxColumn3.HeaderText = "naimenovanie";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "telefon";
            this.dataGridViewTextBoxColumn4.HeaderText = "telefon";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // kniga_izdatelstvoBindingSource
            // 
            this.kniga_izdatelstvoBindingSource.DataMember = "kniga-izdatelstvo";
            this.kniga_izdatelstvoBindingSource.DataSource = this.knijni_magazDataSet;
            // 
            // kniga_izdatelstvoDataGridView
            // 
            this.kniga_izdatelstvoDataGridView.AutoGenerateColumns = false;
            this.kniga_izdatelstvoDataGridView.BackgroundColor = System.Drawing.Color.SkyBlue;
            this.kniga_izdatelstvoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kniga_izdatelstvoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.kniga_izdatelstvoDataGridView.DataSource = this.kniga_izdatelstvoBindingSource;
            this.kniga_izdatelstvoDataGridView.Location = new System.Drawing.Point(450, 28);
            this.kniga_izdatelstvoDataGridView.Name = "kniga_izdatelstvoDataGridView";
            this.kniga_izdatelstvoDataGridView.Size = new System.Drawing.Size(244, 394);
            this.kniga_izdatelstvoDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "id_kniga";
            this.dataGridViewTextBoxColumn5.HeaderText = "id_kniga";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "opisanie";
            this.dataGridViewTextBoxColumn6.HeaderText = "opisanie";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // Izdatelstva
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(697, 426);
            this.Controls.Add(this.kniga_izdatelstvoDataGridView);
            this.Controls.Add(this.izdatelstvoDataGridView);
            this.Controls.Add(this.izdatelstvoBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Izdatelstva";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Издательства";
            this.Load += new System.EventHandler(this.Izdatelstva_Load);
            ((System.ComponentModel.ISupportInitialize)(this.knijni_magazDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.izdatelstvoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.izdatelstvoBindingNavigator)).EndInit();
            this.izdatelstvoBindingNavigator.ResumeLayout(false);
            this.izdatelstvoBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.izdatelstvoDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kniga_izdatelstvoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kniga_izdatelstvoDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private knijni_magazDataSet knijni_magazDataSet;
        private System.Windows.Forms.BindingSource izdatelstvoBindingSource;
        private knijni_magazDataSetTableAdapters.izdatelstvoTableAdapter izdatelstvoTableAdapter;
        private knijni_magazDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator izdatelstvoBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton izdatelstvoBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView izdatelstvoDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private knijni_magazDataSetTableAdapters.kniga_izdatelstvoTableAdapter kniga_izdatelstvoTableAdapter;
        private System.Windows.Forms.BindingSource kniga_izdatelstvoBindingSource;
        private System.Windows.Forms.DataGridView kniga_izdatelstvoDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}